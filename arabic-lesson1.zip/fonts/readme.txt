Folder location for any custom global fonts. Fonts located in this folder can be accessed in the theme by using the 'fonts/' file path.
